PLANT PAPER DIGEST

What it does
  Pulls every new paper from Europe PMC (PubMed + preprints), bioRxiv and
  Crossref (about 30 journals checked directly), keeps the plant papers,
  scores them against your keywords, merges preprint + journal versions,
  skips anything shown in an earlier digest, and writes a reading list.

First run
  1. Double-click run_digest.bat. For the first run you may want a longer
     window: open a command prompt in this folder and type
         run_digest.bat --days 30
  2. The digest opens in your browser (digests\latest.html).
  3. If something looks wrong, run_log.txt has the details.

Weekly
  Double-click setup_weekly_task.bat once. The digest then runs every
  Monday at 08:30, or at your next login if the computer was off.
  Mac/Linux: add to crontab (crontab -e):
    30 8 * * 1  cd /path/to/paper-digest && python3 digest.py >> run_log.txt 2>&1
  If the computer stays off for weeks, the next run catches up (up to 60 days).

Curating
  Tick the papers you want. Ticks are remembered in that browser.
  "Copy ticked" puts formatted references on the clipboard.
  "Download ticked as RIS" gives a file you can drag into Zotero.

Tuning
  Everything is in profiles.txt (instructions at the top of that file).
  - Too many papers: raise min_score, or lower weights of generic terms.
  - A paper you expected is missing: rerun with --ignore-seen and check
    the "matched:" line of similar papers, then add the missing term.
  The score is shown at the top right of each paper.

Files
  digest.py       the program
  profiles.txt    your keywords, sections, journal list
  seen.json       papers already shown (delete it to start fresh)
  state.json      date of the last successful run per source
  digests\        all digests (HTML + CSV)
